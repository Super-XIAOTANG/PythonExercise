from distutils.core import setup
# name 模块名称
# version 版本号
# description  描述
# author 作者
# py_modules 要发布的内容

setup(name='myModule', version='1.0', description='myModule', author='崽崽', py_modules=['myModule'])

# 创建模块 python setup.py build
# 生成压缩包 python setup.py sdist
